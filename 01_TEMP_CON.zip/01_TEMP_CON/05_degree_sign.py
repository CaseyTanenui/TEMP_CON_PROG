degree_sign = u'\N{DEGREE SIGN}'

test_cases = [2, 4, 23.2]

for item in test_cases:
    print("{}{}c".format(item, degree_sign))