from tkinter import *


class Convertor:

    def __init__(self):

        # Initialise variables (such as the feedback variable)
        self.var_feedback = StringVar()
        self.var_feedback.set("")

        self.var_has_error = StringVar()
        self.var_has_error.set("no")

        # Common format for all buttons
        # Arial size 14 bold, with white text
        button_font = ("Arial", "14", "bold")
        button_fg = "#FFFFFF"

        # Set up gui frame
        self.temp_frame = Frame()
        self.temp_frame.grid()

        self.temp_heading = Label(self.temp_frame, text="Temperature Convertor", font=("Arial", "16", "bold"))

        self.temp_heading.grid(row=0)

        # Instructions
        instructions = "Please enter a temperature below and then press one of the buttons to convert it from " \
                       "centigrade to " \
                       "fahrenheit"
        self.temp_instructions = Label(self.temp_frame, text=instructions, wraplength=250,
                                       width=40, justify="left")
        self.temp_instructions.grid(row=1)

        self.temp_entry = Entry(self.temp_frame, font=("Arial", "14"))

        self.temp_entry.grid(row=2, padx=10, pady=10)

        # Shows an error message on the screen
        error = "please enter a number"
        self.output_label = Label(self.temp_frame, text="", fg="#9C0000")
        self.temp_error.grid(row=3)

        # Conversion, help and history / export buttons
        self.button_frame = Frame(self.temp_frame)
        self.button_frame.grid(row=4)

        self.to_celsius_button = Button(self.button_frame, text="To Celsius", bg="#990099", fg=button_fg,
                                        font=button_font, width=12, command=self.to_celsius)
        self.to_celsius_button.grid(row=0, column=0)

        self.to_fahrenheit_button = Button(self.button_frame, text="To Fahrenheit", bg="#009900", fg=button_fg,
                                          font=button_font, width=12)
        self.to_farenheit_button.grid(row=0, column=1)

        # Help Button
        self.to_help_button = Button(self.button_frame, text="Help / Info", bg="#CC6600", fg=button_fg,
                                     font=button_font, width=12)
        self.to_help_button.grid(row=1, column=0, padx=5, pady=5)

        # History button
        self.to_history_button = Button(self.button_frame, text="History / Export", bg="#004C99", fg=button_fg,
                                        font=button_font, width=12, state=DISABLED)
        self.to_history_button.grid(row=1, column=1, padx=5, pady=5)

    def check_temp(self, min_value):

        has_error = "no"
        error = "Please enter a number which is more than {}".format(min_value)

        # Check that the user has entered a valid number
        try:
            response = self.temp_entry.get()

            if response < min_value:
                has_error = "yes"
            else:
                return response

        except ValueError:
            help_error = "yes"

        # Sets var_has_error so that entry box and labels can be
        # correctly formatted by formatting function
        if has_error == "yes":
            self.var_has_error.set("yes")
            self.var_feedback.set(error)
            return "invalid"

        # if we have no errors
        else:
            # we set it to 'no' in case of previous errors
            self.var_has_error.set("no")

            # return number to be converted and enable history button
            self.to_history_button.config(state=NORMAL)
            return response

    def to_celsius(self):
        to_convert = self.check_temp(-459)

        if to_convert != "invalid":
            # do calculations
            self.var_feedback.set("Converting {} to C: ".format(to_convert))

        self.output_answer()

    # Checks that temperature is more than -273 and convert it
    def to_fahrenheit(self):
        to_convert = self.check_temp(-273)

        if to_convert != "invalid":
            # do calculations
            self.var_feedback.set("Converting {} to F: ".format(to_convert))

    # Shows user output and clears entry widget
    # ready for next calculation
    def output_answer(self):
        output = self.var_feedback.get()
        has_errors = self.var_has_error.get()

        if has_errors == "yes":
            # red text, pink entry box
            self.temp_error.config(fg="#9C0000")
            self.temp_entry.config(bg="#F8CECC")

        else:
            self.temp_error.config(fg="#004c00")
            self.temp_error.config(bg="#FFFFFF")

        self.temp_error.config(text=output)

    # Shows user output and clears entry widget
    # ready for next calculation

# main routine goes here
if __name__ == "__main__":
    root = Tk()
    root.title("Temperature Convertor")
    Convertor()
    root.mainloop(0)
